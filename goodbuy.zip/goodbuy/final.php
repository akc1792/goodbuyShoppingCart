<?php

session_start();
?>
<html>
<head>
<style>
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
body{
		font-family:"Comic Sans MS";
background-color:#efefef;}
</style>
</head>
<body>
<a href='cust_category.php' class='button1'>BACK TO CATALOGUE</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
</body>
</html>



<?php

echo "<br><br><br>";
echo "<div>";
echo "Name		:".$_SESSION['fname']."<br><br><br>";
echo "Amount 		 :  Rs".$_SESSION["amount"]."/-<br><br><br>";

echo "Shopping successful . Product(s) will reach by   :";
	
$d=strtotime("+ 7 days");
echo date("M d", $d) . "<br>";	
echo "</div>";

?>
