<?php
// Start the session
session_start();
?>



<html>
<head>
<style>
	body{
		font-family:"Comic Sans MS";}
input,select{

border-radius: 5px;
}
select{
width: 210px;}
.curso {cursor: pointer;}
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2 {
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
 background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
</style>
</head>
<body>
<a href='admin_menu.html' class='button1'>BACK TO MENU</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
<form action="insert_wom_sub.php" name="eidt" method="POST" >
<center>
<table style="padding: 5px 5px 5px 10px;" width="100%" height="100%" bgcolor="#efefef" align="center"
cellspacing="2">



<tr>
<td>ITEM ID</td>
<td><input  type=text name=id  size="30"</td>
</tr>

<tr>
<td>ITEM Name</td>
<td><input type="text" name="name" 
size="30"></td>
</tr>

<tr>
<td>ITEM Rate</td>
<td><input type="text" name="rate" 
size="30"></td>
</tr>

<tr>
<td>Size Available</td>
<td><input type="text" name="size" 
size="30"></td>
</tr>

<tr>
<td> Path</td>
 
<td><input type="text" name="path" 
size="30"></td>

 








 
<tr>

<td><br /><input type="reset" class="curso"></td>
<td colspan="2"><br /><input type="submit" value="Add item"/></td>
</tr>





</table>
</center>
</form>
</body>
</html>
