select * from women;
INSERT INTO women VALUES(10001,"Christy World Sleeved Jacket",4000,"S,M,L,XL",1,"/images/women/w1.jpg");
INSERT INTO women VALUES(10002,"Ethnic Salwar Set",7000,"S,M,L",1,"/images/women/w2.jpg");
INSERT INTO women VALUES(10003,"Mauryas Salwar Set",4200,"L,XL",1,"/images/women/w3.jpg");
INSERT INTO women VALUES(10004,"Vogueish Freyly Wear",4000,"S,M,XL",1,"/images/women/w4.jpg");
INSERT INTO women VALUES(10005,"Harpa Floral Denim Skirt",4100,"S,M,L",1,"/images/women/w5.jpg");
INSERT INTO women VALUES(10006,"Edmiral FLowing SilkGown",3200,"X,XL",1,"/images/women/w6.jpg");
INSERT INTO women VALUES(10007,"Rajadhani Salwar Suite",3000,"S,XL",1,"/images/women/w7.jpg");
INSERT INTO women VALUES(10008,"Kenly Hart Western Wear",2030,"S,M,XL",1,"/images/women/w8.jpg");
INSERT INTO women VALUES(10009,"Jodhpur Silk Salwar",2000,"S,M,L,XL",1,"/images/women/w9.jpg");
INSERT INTO women VALUES(100010,"Mayapuri Kotta Set",4000,"S,M",1,"/images/women/w10.jpg");

drop database goodbuy;
select * from cart;
delete  from women where itemid >1;
