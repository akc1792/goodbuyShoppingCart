<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$p1=$_POST["p1"];


$p2=$_POST["p2"];


$email=$_SESSION["email"];
if($p1!=$p2)
{

header("Location: changepassword.php");

}

$sql = "UPDATE customer SET password='$p1' WHERE email='$email'";




if ($conn->query($sql) === TRUE) {
     header("Location: first_page.php");
} else {
       echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
