select * from budget;

insert into budget values(2018,"february",24235,44445,32324);

insert into budget values(2018,"january",2835,426445,32624);
insert into budget values(2017,"december",22235,421445,82324);
insert into budget values(2017,"november",2235,401445,46324);
insert into budget values(2017,"october",78235,02445,96524);
insert into budget values(2017,"february",44235,21445,78324);
insert into budget values(2017,"july",55235,821445,72324);
insert into budget values(2017,"june",48235,921445,86324);
insert into budget values(2017,"may",28235,621445,68324);
insert into budget values(2017,"april",84235,521445,79324);
insert into budget values(2017,"march",26235,521445,87324);
insert into budget values(2017,"february",85235,721445,97324);
insert into budget values(2017,"january",97235,721445,68624);