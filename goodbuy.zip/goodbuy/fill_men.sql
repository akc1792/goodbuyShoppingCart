INSERT INTO men VALUES(20001,"Nemesis Men's Formals",4000,"S,M,L,XL",2,"/images/men/m1.jpg");
INSERT INTO men VALUES(20002,"Elvis Men's Formals",7000,"S,M,L",2,"/images/men/m2.jpg");
INSERT INTO men VALUES(20003,"R&R Desi Kurtas",4200,"L,XL",2,"/images/men/m3.jpg");
INSERT INTO men VALUES(20004,"Vogueish Freyly Men's Wear",4000,"S,M,XL",2,"/images/men/m4.jpg");
INSERT INTO men VALUES(20005,"Denim Formals",4100,"S,M,L",2,"/images/men/m5.jpg");
INSERT INTO men VALUES(20006,"Dinklage Casuals",3200,"X,XL",2,"/images/men/m6.jpg");
INSERT INTO men VALUES(20007,"Cool & Crazy Casuals Co",3000,"S,XL",2,"/images/men/m7.jpg");
INSERT INTO men VALUES(20008,"Formal Festoons",2030,"S,M,XL",2,"/images/men/m8.jpg");
INSERT INTO men VALUES(20009,"B4Boys Men's Formals",2000,"S,M,L,XL",2,"/images/men/m9.jpg");
INSERT INTO men VALUES(200010,"Arrow Formals",4000,"S,M",2,"/images/men/m10.jpg");

select * from men;