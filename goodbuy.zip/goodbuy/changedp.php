<?php
session_start();
?>

<html>
<head>
<script type='text/javascript'>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
document.getElementById('old').style.display = 'none';
}
</script>
<style>
body
{
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;

}
#wrapper
{
 text-align:center;
 margin:200px 400px ;
 padding:0px;height:500px;
 width:400px;border:1px solid black;
}
#output_image
{
 max-width:300px;
}
</style>
</head>
<body>
<div id="wrapper">
<form method="POST" action="upload_file.php" enctype="multipart/form-data">
 <input type="file" accept="image/*" name="myimage" onchange="preview_image(event)">
<div id="old">
<?php $path=$_SESSION["path"];echo "<img src='$path' id='dp'> "?></div>
 <input type="submit" name="submit_image" value="Upload">
</form>

 <img id="output_image"/>
</div>
</body>
</html>
