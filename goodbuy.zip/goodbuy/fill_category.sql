
select * from category;
drop database goodbuy;
INSERT INTO category VALUES(1,"WOMEN FASHION","/images/homepage/f1.jpg");
INSERT INTO category VALUES(2,"MEN FASHION","/images/homepage/f2.jpg");
INSERT INTO category VALUES(3,"MOBILE","/images/homepage/f3.jpg");
INSERT INTO category VALUES(4,"BABYCARE","/images/homepage/f4.jpg");
INSERT INTO category VALUES(5,"GIFTS","/images/homepage/f5.jpg");
INSERT INTO category VALUES(6,"PAINTINGS","/images/homepage/f6.jpg");
INSERT INTO category VALUES(7,"KIDS","/images/homepage/f7.jpg");
INSERT INTO category VALUES(8,"BOOKS","/images/homepage/f8.jpg");
INSERT INTO category VALUES(9,"JEWELLERY","/images/homepage/f9.jpg");
INSERT INTO category VALUES(10,"OPTICALS","/images/homepage/f10.jpg");
