<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id=$_POST["id"];
$name=$_POST["name"];
$rate=$_POST["rate"];
$size=$_POST["size"];
$path=$_POST["path"];


$sql="INSERT INTO women(itemid,itemname,itemrate,size_available,path,categoryid) 
VALUES ('$id','$name','$rate','$size','$path',1)";
if($conn->query($sql) === TRUE) {
 
   header("Location: 1_ad_admin.php");
}
else
echo "Error: " . $sql . "<br>" . $conn->error;





























$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
