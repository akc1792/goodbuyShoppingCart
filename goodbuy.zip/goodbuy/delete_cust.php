<?php
// Start the session
session_start();
?>


<html>

<head>

<style>
*{
font-family: Comic Sans MS;

}
body{
background-color:#efefef;
}
img{border-radius:20%;}
td{text-align:center;
}
table,td,th{
border-collapse:collapse;
}
table,th{border:none;}
</style>

</head>








</html>
<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cart = $_POST['bag'];

  if(empty($cart))

  {
 //header("Location: ad_customer.php");
    

  }

  else

  {

    $N = count($cart);

 

    for($i=0; $i < $N; $i++)

    {

$email=$cart[$i];

$sql="DELETE FROM customer WHERE email='$email' ";


if($conn->query($sql) === TRUE) {
  
   
}
else
echo "Error: " . $sql . "<br>" . $conn->error;

}}
$cart1 = $_POST['bag1'];

  if(empty($cart1))

  {
 header("Location: ad_customer.php");
    

  }

  else

  {

    $N = count($cart1);

 

    for($i=0; $i < $N; $i++)

    {

$email=$cart1[$i];

$sql="SELECT * FROM cart where customer_id ='$email'";
$category=1;
$result=$conn->query($sql);
echo "<form action='delete_cart_ad.php' method='post'>";

echo "<table align='center' border='1' width='90%' cellpadding='10'>";
//echo "<th> DISPLAY </th>  <th> TITLE </th>  <th> ID </th> <th>SIZES AVAILABLE </th>";

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	echo "<tr>";
		$name=$row["itemname"];$rate=$row["itemrate"];$path=$row["path"];$id=$row["itemid"];
		
		echo "<td width='30%'>$id</td>  <td width='30%'> $name</td> <td width='30%'>$rate</td>
		 <td width='40%'><img src=$path>REMOVE<input type='checkbox' name='bag3[]' value=$id />
</td>  <br><br> ";
	
		echo "</tr>";
		
        }
echo "</table>";
     echo "<input type='submit' name='formSubmit' value='CONFIRM ACTION' class='button1'/>";   
}



















    }//forloop

  }//big else

//header("Location: ad_customer.php");
$conn->close();
?>
