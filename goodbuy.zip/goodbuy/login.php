<?php
// Start the session
session_start();
?>

<html>

<body>
<?php
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username=$_POST["username"];
$password=$_POST["psw"];


$sql= "SELECT * FROM customer WHERE '$username'=email and '$password'=password";

$result = $conn->query($sql);
if($result->num_rows > 0)
{
	while($row = $result->fetch_assoc()) {
		$_SESSION["fname"]=$row["fname"];
$_SESSION["email"]=$row["email"];$_SESSION["sec"]=$row["securityqn"];$_SESSION["ans"]=$row["answer"];
  $_SESSION["phone"]=$row["mob"];
  $_SESSION["gender"]=$row["gender"];
  $_SESSION["psw"]=$row["password"];$_SESSION["path"]=$row["path"];$_SESSION["custid"]=$row["id"];
 $_SESSION["lname"]=$row["lname"]; $_SESSION["dob"]=$row["dob"]; $_SESSION["bio"]=$row["bio"]; $_SESSION["addr"]=$row["addr"]; 



    }



    header("Location: first_page.php");


}
else
    header("Location: login_error.html");
$conn->close();
?>



</body>
</html>

