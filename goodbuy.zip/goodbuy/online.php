<?php
// Start the session
session_start();
?>


<html>
<head>
<style>
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;


}
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.lg{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;

}
fieldset{

border:none;
}
	body{
		font-family:"Comic Sans MS";}
input,select{

border-radius: 5px;
}
select{
width: 210px;}
.curso {cursor: pointer;}
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2 {
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
 background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
</style>
</head>
<body>
<a href='cust_category.php' class='button1'>BACK TO CATALOGUE</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
</body>
</html>






<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username=$_SESSION["email"];
$sql="select * from customer where email='$username'";


$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	
		$id=$row["id"];$fname=$row["fname"];$mob=$row["mob"];

		echo "<br><br><br><br>CUSTOMER NAME		:	".$fname."<br><br><br>";

                echo "CONTACT NUMBER		:	".$mob."<br><br><br>";
		echo "EMAIL ADDRESS		:	".$username."<br><br><br>";
                echo "AMOUNT			:	".$_SESSION['amount']."<br><br>";

        }//row
        
}//result
else
        echo "Error: " . $sql . "<br>" . $conn->error;



//header("Location: viewcart.php");
$conn->close();
?>
<html><body>
<section>
<form id=payment action=final.php>
    
  
    <fieldset>
        <legend>DELIVERY ADDRESS</legend><br>
        <ol>
            <li>
                <label for=address>Address</label><br><br>
                <textarea id=address name=address rows=5 required>
                </textarea>
            </li>
            <li>
                <label for=postcode>Post Code</label><br><br>
                <input id=postcode name=postcode type=text required />
 
            </li>
            <li>
                <label for=country>Country</label><br><br>
                <input id=country name=country type=text required />
            </li>
        </ol>
    </fieldset>
    <fieldset>
        <legend>CARD DETAILS</legend><br>
        <ol>
            <li>
            <fieldset>
                <legend>Card Type</legend><br><br>
                <ol>
                    <li>
                        <input id=visa name=cardtype type=radio />
                        <label for=visa>VISA</label><br><br>
                    </li>
                    <li>
                        <input id=amex name=cardtype type=radio />
                        <label for=amex>AmEx</label><br><br>
                    </li>
                    <li>
                        <input id=mastercard name=cardtype type=radio />
                        <label for=mastercard>Mastercard</label><br><br>
                    </li>
                </ol>
            </fieldset>
            </li>
            <li>
                <label for=cardnumber>Card Number</label>
                <input id=cardnumber name=cardnumber type=number required /><br><br>
            </li>
            <li>
                <label for=secure>Security Code</label>
                <input id=secure name=secure type=number required /><br><br>
            </li>
            <li>
                <label for=namecard>Name on Card</label><br><br>
                <input id=namecard name=namecard type=text placeholder="Exact namne as on the card" required />
            </li>
        </ol>
    </fieldset>
    <fieldset>
       <a href="final.php"> <button type=submit class=button>Finish Transaction</button></a>
    </fieldset>
</form>
</section>
</body></html>
