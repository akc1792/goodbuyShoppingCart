<?php
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username=$_POST["username"];
$password=$_POST["psw"];

$sql= "SELECT * FROM admin WHERE '$username'=username and '$password'=password";
$result = $conn->query($sql);
if($result->num_rows > 0)
    header("Location: admin_menu.html");
else
    header("Location: login_error.html");
$conn->close();
?>
<html>

<body>



</body>
</html>

