INSERT INTO gift VALUES(50001,"Optimist Image Book",4000,"d",5,"/images/gifts/g1.jpg");
INSERT INTO gift VALUES(50002,"Archers Xmas Gift",7000,"d",5,"/images/gifts/g2.jpg");
INSERT INTO gift VALUES(50003,"Herbies' Gift Pack",4200,"d",5,"/images/gifts/g3.jpg");
INSERT INTO gift VALUES(50004,"Sally Handmade Earring",4000,"d",5,"/images/gifts/g4.jpg");
INSERT INTO gift VALUES(50005,"Cafideria Cards",4500,"d",5,"/images/gifts/g5.jpg");
INSERT INTO gift VALUES(50006,"Dazy Xmas Card",3200,"d",5,"/images/gifts/g6.jpg");
INSERT INTO gift VALUES(50007,"Xmas Floral Ring",3000,"d",5,"/images/gifts/g7.jpg");
INSERT INTO gift VALUES(50008,"Gifty POST Cards",2030,"d",5,"/images/gifts/g8.jpg");
INSERT INTO gift VALUES(50009,"Simon's Xmas Tree",2000,"d",5,"/images/gifts/g9.jpg");
INSERT INTO gift VALUES(500010,"Melie's Handmade Earring",4000,"d",5,"/images/gifts/g10.jpg");

select * from gift;
delete from gift where categoryid=1;