<?php
// Start the session
session_start();
?>



<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bag = $_POST['bag3'];

  if(empty($bag))

  {
header("Location: delete_cust.php");

  }

  else

  {

    $N = count($bag);

 

    for($i=0; $i < $N; $i++)

    {

$itemid=$bag[$i];


$sql="delete  from cart where itemid='$itemid'";





if($conn->query($sql) === TRUE) {

header("Location: delete_cust.php");

}
else
{}

    }//forloop

  }//big else
//header("Location: viewcart.php");
//header("Location: viewcart.php");
$conn->close();
?>
