<?php
// Start the session
session_start();
?>



<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cart = $_POST['bag'];

  if(empty($cart))

  {
 header("Location: ad_catalogue.php");
    

  }

  else

  {

    $N = count($cart);

 

    for($i=0; $i < $N; $i++)

    {

$email=$cart[$i];

$sql="DELETE FROM category WHERE categoryname='$email' ";


if($conn->query($sql) === TRUE) {
  
   
}
else
echo "Error: " . $sql . "<br>" . $conn->error;


















    }//forloop

  }//big else

header("Location: ad_catalogue.php");
$conn->close();
?>
