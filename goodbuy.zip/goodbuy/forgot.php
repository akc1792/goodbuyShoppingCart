<!DOCTYPE html>
<html>
<style>

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
fieldset{
display: inline-block;

}
fieldset
{
    height:400px;
    width: 30%;
    background: #ffffff;
    text-align:center;
    margin:50px 50px 50px 450px;
}
body{font-size:20px;font-family:Comic Sans MS;background-color:#efefef;}
</style>
<body>

<form action="mail.php" enctype="multipart/form-data" method="post">
 <fieldset>
  <legend align="center">Forgot Password</legend><br><br><br><br>
  Enter your username : <input type="text" name="username" required><br><br><br><br><br>
  <input type="submit" class="button" value="Answer Security Question...">
 </fieldset>
</form>

</body>
</html>

