<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$imagename=$_FILES["myimage"]["name"];

$imagetmp=addslashes (file_get_contents($_FILES['myimage']['tmp_name']));

$_SESSION['path']=$imagename;
$email=$_SESSION['email'];
$sql = "UPDATE customer SET path='$imagename' WHERE email='$email'";
if($conn->query($sql) === TRUE) {
   header("Location: first_page.php");
}
else
echo "Error: " . $sql . "<br>" . $conn->error;
$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
